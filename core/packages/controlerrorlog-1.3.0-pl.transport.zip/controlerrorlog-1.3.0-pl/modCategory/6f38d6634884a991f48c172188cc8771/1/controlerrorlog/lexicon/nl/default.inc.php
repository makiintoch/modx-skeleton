<?php
$_lang['error_log'] = 'Foutlog';
$_lang['cel_refresh'] = 'Verversen';
$_lang['cel_clear'] = 'Legen';
$_lang['cel_close'] = 'Sluiten';
$_lang['cel_delete'] = 'Delete';
$_lang['cel_copy'] = 'Make a copy';
$_lang['errors_title'] = 'Open foutlog in een nieuw venster';
$_lang['errorlog_last_lines'] = 'De laatste [[+last]] regels.';
$_lang['errorlog_download'] = 'Download';
$_lang['errorlog_too_large'] = 'Het foutlog op is te groot om weer te geven. Download het foutlog via onderstaande knop.';
$_lang['errorlog_email_subject'] = 'Er zijn fouten in het foutlog weggeschreven';
$_lang['errorlog_email_body'] = 'Bekijk de foutlog ("[[+siteName]]").';
