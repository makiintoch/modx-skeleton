<?php
$_lang['error_log'] = 'Error log';
$_lang['cel_refresh'] = 'Refresh';
$_lang['cel_clear'] = 'Clear';
$_lang['cel_close'] = 'Close';
$_lang['cel_delete'] = 'Delete';
$_lang['cel_copy'] = 'Make a copy';
$_lang['errors_title'] = 'Open the error log in a new window';
$_lang['errorlog_last_lines'] = 'The last [[+last]] lines.';
$_lang['errorlog_download'] = 'Download';
$_lang['errorlog_too_large'] = 'The error log is too large to be viewed. You can download it via the button "Download".';
$_lang['errorlog_email_subject'] = 'Detected some errors on the site';
$_lang['errorlog_email_body'] = 'Check the system error log on the site "[[+siteName]]".';