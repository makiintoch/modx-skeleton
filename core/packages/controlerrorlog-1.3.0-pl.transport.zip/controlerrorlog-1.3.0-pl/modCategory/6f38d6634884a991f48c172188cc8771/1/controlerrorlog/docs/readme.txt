--------------------
controlErrorLog
--------------------
Author: Sergey Shlokov <sergant210@bk.ru>
--------------------

This Extra adds a new feature to manager interface - the ability to control the error log and view it in a popup window.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/sergant210/controlErrorLog/issues